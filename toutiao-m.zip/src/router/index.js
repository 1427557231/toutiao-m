import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/login/index') // 直接配置路由加载
  }
]

const router = new VueRouter({
  routes
})

export default router
